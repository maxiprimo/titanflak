
import sys
import os
import math
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error
from xgboost import XGBRegressor

# get close price ticks
def get_data(path, step):
	f = open(path)
	close_arr = []
	steps = 5
	count = 0
	while True:
		line = f.readline()
		if not line:
			break
		items = line.split("|");
		if(count%step==0):
			close_arr.append(float(items[1]))
		count = count+1
	f.close()
	return close_arr

data = get_data('market.txt', 5) # price data
data = data[-50*1000:]
steps_in, steps_out = 50,50
offset = 10000
data1 = data[:-offset]
data2 = data[-offset:-(offset-steps_in-steps_out)]
model_file = "model.pkl"

# transform a time series dataset into a supervised learning dataset
def series_to_supervised(data, n_in=1, n_out=1):
	n_vars = 1 if type(data) is list else data.shape[1]
	df = pd.DataFrame(data)
	cols = list()
	for i in range(n_in, 0, -1):
		cols.append(df.shift(i))
	for i in range(0, n_out):
		cols.append(df.shift(-i))
	agg = pd.concat(cols, axis=1)
	agg.dropna(inplace=True)
	return agg.values
 
# fit an xgboost model and make a one step prediction
def xgboost_forecast(testX, model):
	# make a one-step prediction
	yhat = model.predict(np.asarray([testX]))
	return yhat[0]
 
# walk-forward validation for univariate data
def walk_forward_validation(train, test):
	predictions = list()
	history = [x for x in train]
	train = np.asarray(train)
	trainX, trainy = train[:, :-1], train[:, -1]
	#model = pickle.load(open(model_file, "rb"))
	model = XGBRegressor(objective='reg:squarederror', n_estimators=1000)
	model.fit(trainX, trainy)
	pickle.dump(model, open(model_file, "wb"))
	for i in range(len(test)):
		testX, testy = test[i, :-1], test[i, -1]
		yhat = xgboost_forecast(testX, model)
		predictions.append(yhat)
	error = mean_absolute_error(test[:, -1], predictions)
	return error, test[:, -1], predictions
 
train = series_to_supervised(data1, n_in=steps_in)
test = series_to_supervised(data2, n_in=steps_in)
mae, y, yhat = walk_forward_validation(train, test)
print('mean_error: %.3f' % mae)
plt.plot(y, color='black' , linewidth=0.5)
plt.plot(yhat, color='red', linewidth=0.5)
plt.show()
